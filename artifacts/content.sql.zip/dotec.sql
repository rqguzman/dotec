-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Set 14, 2011 as 12:03 AM
-- Versão do Servidor: 5.1.50
-- Versão do PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `dotec`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cpf` varchar(255) DEFAULT NULL,
  `dataDeNascimento` datetime DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `rg` varchar(255) DEFAULT NULL,
  `sexo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `cliente`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text,
  `isHomePage` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `page` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Extraindo dados da tabela `content`
--

INSERT INTO `content` (`id`, `content`, `isHomePage`, `ordering`, `page`, `status`, `title`) VALUES
(1, '<p>A DOTEC produz soluções em gestão da informação, arquivamento, organização, segurança, sigilo e administração de arquivos. Disponibilizamos uma ferramenta em que você pode escolher os tipos de serviços através da web. Não tem perda de tempo, muito menos de dinheiro.</p>\r\n						<p> Nosso objetivo principal é a organização da informação documental de grandes, médias, pequenas, microempresas e profissionais liberais, auxiliando-os na guarda de seus documentos.                           </p><p> Queremos atender com excelência a todos os nossos clientes, por isso, organizamos todos os tipos de informações da empresa, criamos políticas de guarda e recuperação de documentos.   Conheça nossos serviços: </p>', 1, 1, 'apresentacao.html', 3, 'Apresentação'),
(2, '<h3>Guarda Terceirizada de Documentos</h3>\r\n						<p>Você precisa saber quais são os prazos exigidos por lei para o armazenamento dos seus documentos. Assim, você poderá ficar tranqüilo e seguro que a DOTEC cuidará do resto. </p>\r\n						<p>Não é fácil ser um profissional organizado 24 horas por dia em todos os dias da semana. Alguns conseguem mais que outros mas, normalmente, nos perdemos na administração do tempo. </p>\r\n						<p>A organização pessoal envolve acabar com velhos hábitos e formar novos, preferencialmente, mais eficazes. Ainda mais quando temos que guardar documentos por tempos muito longos que são exigidos pela Legislação Brasileira, como FGTS em que a norma determina a prescrição de 30 anos.</p>\r\n						<p>A DOTEC dá todo o suporte para você não ter problemas no futuro por uma simples perda de documentos. Temos uma área com espaço físico adequado para manter a integridade de qualquer tipo de documento, desde caixas, pastas, envelopes, livros, desenhos, projetos, até plantas técnicas e outros.</p>\r\n						<p>A proteção, indexação e o completo sigilo dos documentos são itens fundamentais em qualquer projeto da DOTEC. Os procedimentos para destruição de documentos, também, obedecem aos mais rigorosos padrões de segurança, sempre de acordo com a demanda do cliente.</p>\r\n						<table>\r\n							<thead>\r\n								<tr>\r\n									<td>Documento</td>\r\n									<td>Tempo</td>\r\n								</tr>\r\n							</thead>\r\n							<tbody>\r\n								<tr>\r\n									<td>Folha de Pagamento</td>	\r\n									<td>30 anos</td>	\r\n								</tr>\r\n								<tr>\r\n									<td>Guia de INSS</td>\r\n									<td>30 anos</td>\r\n								</tr>\r\n								<tr>		\r\n									<td>Guia de Recolhimento de FGTS</td>\r\n									<td>30 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>INPS</td>\r\n									<td>30 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Recibo de Pagamento de Autônomo</td>\r\n									<td>30 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Termo de Rescisão de Contrato de Trabalho (TRCT)</td>\r\n									<td>30 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Comprovante de Acidente no Trabalho</td>\r\n									<td>20 anos</td>\r\n								</tr>\r\n								<tr>	\r\n									<td>Contrato de trabalho</td>\r\n									<td>20 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Contrato de Experiência</td>\r\n									<td>20 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Adicional de Insalubridade</td>\r\n									<td>20 anos</td>\r\n								</tr>											\r\n								<tr>\r\n									<td>Processo trabalhista</td>\r\n									<td>20 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Holerite de Pagamento</td>\r\n									<td>10 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>RAIS</td>\r\n									<td>10 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Salário - Família</td>\r\n									<td>10 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Declaração de Contribuição de Tributos Federais</td>\r\n									<td>10 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Livro de Registro de Saída</td>\r\n									<td>10 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Cofins</td>\r\n									<td>10 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Aviso Prévio</td>\r\n									<td>5 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Cartão de Ponto</td>\r\n									<td>5 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Contrato de Estágio</td>\r\n									<td>5 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Adicional de Periculosidade</td>\r\n									<td>5 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Ponto Eletrônico</td>\r\n									<td>5 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Vale - Transporte</td>\r\n									<td>5 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Demonstrativo de Apuração e Informação do ICMS</td>\r\n									<td>5 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Livro de Registro do ICMS</td>	\r\n									<td>5 anos</td>\r\n								</tr>\r\n								<tr>\r\n									<td>Movimento de Caixa</td>\r\n									<td>5 anos</td>\r\n								</tr>\r\n							</tbody>\r\n						</table>', 1, 2, 'para-voce.html', 3, 'Para Você'),
(3, '<h3>Organização de arquivos</h3>\r\n						<p>No Brasil, a exigência do preenchimento de inúmeros papéis é um dos principais obstáculos para o crescimento do nosso país, o peso da burocracia é bem maior para o empresário brasileiro do que para os empresários de outros países.</p>\r\n						<p>A produção de um número enorme de documentos, também, requer um critério de organização excelente, facilitando assim, a vida do empresário que desejar localizar com rapidez qualquer documento, principalmente no atendimento a fiscalização.</p>\r\n						<p>A DOTEC organiza com metodologia de arquivamento adequada para cada tipo de documento. Com a organização da documentação da sua empresa, você terá acesso imediato a informações importantes que agilizam o trabalho de todos os colaboradores e melhora significativamente seus ganhos na produtividade.</p>\r\n						<p>Como a informação é o quarto fator de produção, não há quem questione que a rapidez em adquirir as informações documentais é fundamental e, portanto, é um investimento de alto retorno.</p>\r\n						<p>Definindo toda a logística junto com você ou alguém de sua confiança, A DOTEC sabe que pode fornecer grandes benefícios para sua empresa, entre eles: saber o que arquivar, onde arquivar e como fazê-lo. Padronizar os títulos dos documentos. Definir o tempo de arquivamento de cada documento. Atender a fiscalização com tranqüilidade. E por fim, treinar os usuários do sistema implantado, conscientizando-os da necessidade de manutenção do mesmo.</p>', 1, 3, 'para-sua-empresa.html', 3, 'Para sua empresa'),
(4, '<p>Se você é um profissional liberal – médico, contador, advogado, administrador e tantos outros - ou uma Empresa de médio e pequeno porte, com certeza já teve problemas com espaço físico para organizar tantos documentos exigidos por lei que precisam ser guardados por um longo tempo.\r\n\r\n</p><p>Além disso, pastas fora do lugar ou documentos que se perdem são problemas comuns e podem trazer resultados desastrosos e indesejáveis. E ainda, funcionários que passam a maior parte do dia tentando organizar os documentos ou encontrá-los, apresentam uma perda de, aproximadamente, 40% do tempo de serviço.  \r\n\r\n</p><p>Com a DOTEC, você pode transformar o espaço ocupado com os documentos, de obrigatoriedade legal e fiscal, em um espaço para sua atividade fim, ou seja, transformar uma área improdutiva que gera somente custos e incômodos, em uma área útil e produtiva. Ao liberar o espaço, você está investindo no melhor aproveitamento das salas e, principalmente, liberando sua força de trabalho para atividades mais focadas. \r\n\r\n</p><p>Além dos problemas de espaço físico e melhorias no ambiente de trabalho, você pode diminuir os custos operacionais necessários para cuidar dos arquivos ativos, intermediários e inativos. \r\n\r\n</p><p>A DOTEC cuida de todo o processo para que você economize no custo do espaço-físico, na adequação deste espaço para preservação dos documentos, na manutenção dos arquivos, nos gastos com luz, limpeza e funcionários para seu manuseio, no tempo para a localização de algum documento, entre outros itens que geram despesas para gerenciar um arquivo.\r\n\r\n</p><p>E mais, a DOTEC disponibiliza profissionais especializados, atualizados e treinados para solucionar e gerenciar arquivos com segurança e sigilo, garantindo a qualidade dos serviços prestados aos seus clientes.\r\n\r\n</p><p>Terceirizar esse tipo de serviço é a tendência do mercado atual para grandes, médias, pequenas, microempresas e profissionais liberais que queiram melhorar a logística na gestão de seus documentos, facilitando a rapidez no acesso às informações e a integração entre os setores. Em média, a terceirização representa o custo de somente 20% do valor total que você gastaria para manter a guarda dos documentos em suas dependências.\r\n\r\n</p><p>Somos uma Empresa preocupada com o controle, a agilidade, a segurança e a redução de custos para os nossos clientes. \r\n\r\n</p>\r\n\r\n', 1, 4, 'quem-somos.html', 3, 'Quem Somos'),
(5, ' <p>\r\n\r\n                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id lorem et quam fringilla suscipit id non erat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam vestibulum, tellus ac venenatis posuere, tellus enim gravida quam, sed ullamcorper elit arcu sed ipsum. Fusce nunc mauris, posuere sit amet mattis sit amet, tincidunt vitae erat. Etiam blandit tellus id arcu facilisis porttitor. Vestibulum semper ornare nunc ac consequat. Proin leo metus, bibendum ut tristique nec, ullamcorper vel purus. Morbi nec nunc at tortor volutpat dapibus. Nullam et magna nec orci faucibus tempus. Nullam iaculis nisl turpis. Maecenas elementum dolor sed orci aliquet congue. Nullam a elit mauris. Quisque sit amet lorem nibh, eget venenatis nisi. Praesent semper fringilla congue. Etiam id quam eu nunc molestie dapibus vel eleifend eros. Aliquam ut adipiscing nisl. Curabitur vel velit vitae ante egestas ultrices a id velit. Proin eget nunc et leo rutrum vestibulum. Aenean lectus eros, suscipit eu eleifend ut, eleifend et mi.\r\n\r\n                        </p>\r\n\r\n                        <p>\r\n\r\n                        Curabitur mattis diam et arcu interdum cursus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin vel velit ut odio consequat porta vitae at sem. Morbi fringilla, elit feugiat congue commodo, lorem leo suscipit mi, ut condimentum libero ligula non turpis. Nullam fermentum lacinia metus sed tempus. Nam sit amet ante nisi, ut volutpat odio. Praesent auctor ligula sed mi feugiat eget lacinia nunc interdum. Vestibulum placerat sagittis eros, ut tempor mi tincidunt tincidunt. Quisque quis nisi urna. Fusce convallis, magna non condimentum lacinia, erat dolor ullamcorper eros, a imperdiet metus neque vitae mauris. Ut auctor commodo consectetur. Suspendisse potenti. Ut id lorem in odio molestie pulvinar.\r\n\r\n                        </p>\r\n\r\n\r\n\r\n                        <p>\r\n\r\n                        Phasellus libero velit, dignissim nec posuere a, placerat quis lorem. Quisque quam turpis, sollicitudin vitae laoreet id, vulputate et justo. Maecenas ut mi tellus. Sed viverra sagittis molestie. Cras purus nisl, consectetur a tincidunt sit amet, semper sit amet ligula. Praesent feugiat facilisis felis eu blandit. Nullam vulputate, felis ut luctus lobortis, dui tellus consectetur dolor, sed porta nisi ligula a lorem. Mauris nec aliquam sapien. Integer consequat ante et erat tincidunt lobortis ut sit amet libero. Suspendisse vestibulum placerat justo, eu posuere leo suscipit a. Sed tristique tincidunt tempor. Aliquam id posuere enim. Donec pharetra est non leo pellentesque facilisis non a erat. Aenean tempus rhoncus nunc sed consequat. In luctus consequat leo, sed vestibulum dolor varius vitae. Ut faucibus porttitor aliquet. Phasellus ante felis, pulvinar id mattis rhoncus, faucibus vel mauris.\r\n\r\n                        </p>\r\n\r\n                        <p>\r\n\r\n                        Nam sapien massa, placerat a rhoncus eu, tempus at nunc. Suspendisse accumsan adipiscing blandit. Fusce in neque dolor, quis ultrices dolor. Sed blandit, nibh vel convallis porta, neque urna ornare augue, a tempor erat tellus quis quam. Nulla ullamcorper tristique sem, a fringilla diam dapibus sit amet. Suspendisse placerat aliquet turpis, at varius turpis accumsan eget. Mauris commodo malesuada ante. Donec vel sem neque. Nam tincidunt velit a tortor tempus in vestibulum justo molestie. Nullam eget augue urna, sed tempor massa. Praesent nec neque quam, id placerat enim. Integer nec orci nunc, eu tristique lorem. In nec libero ipsum, id venenatis orci. Morbi suscipit risus non justo vestibulum scelerisque vel nec orci. In ipsum ligula, porttitor nec scelerisque vel, auctor ut lectus. Ut convallis, sapien eget porttitor iaculis, nulla nisl rhoncus justo, id dignissim dolor nibh et metus. Proin cursus lacus id lorem convallis eu aliquam dolor malesuada.\r\n\r\n                        </p>\r\n\r\n                        <p>\r\n\r\n                        Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Quisque convallis fermentum gravida. Duis sagittis, velit non dictum condimentum, enim ante ullamcorper velit, sit amet rutrum magna ligula quis metus. Vivamus ut blandit enim. Donec hendrerit ante vitae nibh cursus in euismod nibh posuere. Vestibulum dictum pharetra diam, ac feugiat sem mollis posuere. Ut blandit tristique dui ac molestie. Mauris semper augue id velit condimentum sed egestas orci ornare. Proin purus ipsum, hendrerit sit amet posuere vitae, blandit et nibh. Suspendisse eget sollicitudin ligula. Morbi id bibendum est. Curabitur convallis, sem sit amet adipiscing ornare, mauris risus imperdiet quam, quis porta erat massa sed ipsum.\r\n\r\n                        </p>\r\n', 0, 5, 'tabela-de-precos.html', 3, 'Tabela de Preço'),
(6, 'A DOTEC lhe fornece uma caixa quando você precisar desse serviço, temos uma infraestrutura e organização para atendê-lo da melhor forma possível. As etapas do procedimento são:\r\nPrimeiro - a Onfile envia a quantidade de caixas conforme sua necessidade e solicitação e, também, as etiquetas de identificação. Importante: você controla todo o conteúdo da caixa.\r\nSegundo – através do sistema de gerenciamento de guarda na nossa página XXXX, você cadastra o conteúdo das caixas, lacra e nos informa para que possamos buscá-la e guardá-la.\r\nTerceiro – quando for necessário requerer algum documento, é só nos avisar através do nosso sistema e preencher uma Ordem de Serviço, mais conhecido como O.S.', 0, 0, 'guarda-simples.html', 3, 'Guarda simples'),
(7, 'Se para sua empresa for melhor contratar esse tipo de serviço, a Onfile cuida de tudo para você.\r\nPrimeiro - recepcionamos todos os documentos e controlamos todo o conteúdo nas caixas.\r\nSegundo – cada documento recebe sua etiqueta de identificação com um código de barras que é arquivado em nosso sistema com o número da caixa e sua localização.\r\nTerceiro –quando você precisar de algum desses documentos, solicitamos que entre no nosso sistema e preencha a O.S. Entregamos os documentos no prazo pré-determinado.', 0, 0, 'guarda-gerenciada.html', 3, 'Guarda gerenciada'),
(8, ' <p>\r\n\r\n                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id lorem et quam fringilla suscipit id non erat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam vestibulum, tellus ac venenatis posuere, tellus enim gravida quam, sed ullamcorper elit arcu sed ipsum. Fusce nunc mauris, posuere sit amet mattis sit amet, tincidunt vitae erat. Etiam blandit tellus id arcu facilisis porttitor. Vestibulum semper ornare nunc ac consequat. Proin leo metus, bibendum ut tristique nec, ullamcorper vel purus. Morbi nec nunc at tortor volutpat dapibus. Nullam et magna nec orci faucibus tempus. Nullam iaculis nisl turpis. Maecenas elementum dolor sed orci aliquet congue. Nullam a elit mauris. Quisque sit amet lorem nibh, eget venenatis nisi. Praesent semper fringilla congue. Etiam id quam eu nunc molestie dapibus vel eleifend eros. Aliquam ut adipiscing nisl. Curabitur vel velit vitae ante egestas ultrices a id velit. Proin eget nunc et leo rutrum vestibulum. Aenean lectus eros, suscipit eu eleifend ut, eleifend et mi.\r\n\r\n                        </p>\r\n\r\n                        <p>\r\n\r\n                        Curabitur mattis diam et arcu interdum cursus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin vel velit ut odio consequat porta vitae at sem. Morbi fringilla, elit feugiat congue commodo, lorem leo suscipit mi, ut condimentum libero ligula non turpis. Nullam fermentum lacinia metus sed tempus. Nam sit amet ante nisi, ut volutpat odio. Praesent auctor ligula sed mi feugiat eget lacinia nunc interdum. Vestibulum placerat sagittis eros, ut tempor mi tincidunt tincidunt. Quisque quis nisi urna. Fusce convallis, magna non condimentum lacinia, erat dolor ullamcorper eros, a imperdiet metus neque vitae mauris. Ut auctor commodo consectetur. Suspendisse potenti. Ut id lorem in odio molestie pulvinar.\r\n\r\n                        </p>\r\n\r\n\r\n\r\n                        <p>\r\n\r\n                        Phasellus libero velit, dignissim nec posuere a, placerat quis lorem. Quisque quam turpis, sollicitudin vitae laoreet id, vulputate et justo. Maecenas ut mi tellus. Sed viverra sagittis molestie. Cras purus nisl, consectetur a tincidunt sit amet, semper sit amet ligula. Praesent feugiat facilisis felis eu blandit. Nullam vulputate, felis ut luctus lobortis, dui tellus consectetur dolor, sed porta nisi ligula a lorem. Mauris nec aliquam sapien. Integer consequat ante et erat tincidunt lobortis ut sit amet libero. Suspendisse vestibulum placerat justo, eu posuere leo suscipit a. Sed tristique tincidunt tempor. Aliquam id posuere enim. Donec pharetra est non leo pellentesque facilisis non a erat. Aenean tempus rhoncus nunc sed consequat. In luctus consequat leo, sed vestibulum dolor varius vitae. Ut faucibus porttitor aliquet. Phasellus ante felis, pulvinar id mattis rhoncus, faucibus vel mauris.\r\n\r\n                        </p>\r\n\r\n                        <p>\r\n\r\n                        Nam sapien massa, placerat a rhoncus eu, tempus at nunc. Suspendisse accumsan adipiscing blandit. Fusce in neque dolor, quis ultrices dolor. Sed blandit, nibh vel convallis porta, neque urna ornare augue, a tempor erat tellus quis quam. Nulla ullamcorper tristique sem, a fringilla diam dapibus sit amet. Suspendisse placerat aliquet turpis, at varius turpis accumsan eget. Mauris commodo malesuada ante. Donec vel sem neque. Nam tincidunt velit a tortor tempus in vestibulum justo molestie. Nullam eget augue urna, sed tempor massa. Praesent nec neque quam, id placerat enim. Integer nec orci nunc, eu tristique lorem. In nec libero ipsum, id venenatis orci. Morbi suscipit risus non justo vestibulum scelerisque vel nec orci. In ipsum ligula, porttitor nec scelerisque vel, auctor ut lectus. Ut convallis, sapien eget porttitor iaculis, nulla nisl rhoncus justo, id dignissim dolor nibh et metus. Proin cursus lacus id lorem convallis eu aliquam dolor malesuada.\r\n\r\n                        </p>\r\n\r\n                        <p>\r\n\r\n                        Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Quisque convallis fermentum gravida. Duis sagittis, velit non dictum condimentum, enim ante ullamcorper velit, sit amet rutrum magna ligula quis metus. Vivamus ut blandit enim. Donec hendrerit ante vitae nibh cursus in euismod nibh posuere. Vestibulum dictum pharetra diam, ac feugiat sem mollis posuere. Ut blandit tristique dui ac molestie. Mauris semper augue id velit condimentum sed egestas orci ornare. Proin purus ipsum, hendrerit sit amet posuere vitae, blandit et nibh. Suspendisse eget sollicitudin ligula. Morbi id bibendum est. Curabitur convallis, sem sit amet adipiscing ornare, mauris risus imperdiet quam, quis porta erat massa sed ipsum.\r\n\r\n                        </p>\r\n', 0, 0, 'area-de-atuacao.html', 3, 'Área de Atuação'),
(9, ' <p>\r\n\r\n                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id lorem et quam fringilla suscipit id non erat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam vestibulum, tellus ac venenatis posuere, tellus enim gravida quam, sed ullamcorper elit arcu sed ipsum. Fusce nunc mauris, posuere sit amet mattis sit amet, tincidunt vitae erat. Etiam blandit tellus id arcu facilisis porttitor. Vestibulum semper ornare nunc ac consequat. Proin leo metus, bibendum ut tristique nec, ullamcorper vel purus. Morbi nec nunc at tortor volutpat dapibus. Nullam et magna nec orci faucibus tempus. Nullam iaculis nisl turpis. Maecenas elementum dolor sed orci aliquet congue. Nullam a elit mauris. Quisque sit amet lorem nibh, eget venenatis nisi. Praesent semper fringilla congue. Etiam id quam eu nunc molestie dapibus vel eleifend eros. Aliquam ut adipiscing nisl. Curabitur vel velit vitae ante egestas ultrices a id velit. Proin eget nunc et leo rutrum vestibulum. Aenean lectus eros, suscipit eu eleifend ut, eleifend et mi.\r\n\r\n                        </p>\r\n\r\n                        <p>\r\n\r\n                        Curabitur mattis diam et arcu interdum cursus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin vel velit ut odio consequat porta vitae at sem. Morbi fringilla, elit feugiat congue commodo, lorem leo suscipit mi, ut condimentum libero ligula non turpis. Nullam fermentum lacinia metus sed tempus. Nam sit amet ante nisi, ut volutpat odio. Praesent auctor ligula sed mi feugiat eget lacinia nunc interdum. Vestibulum placerat sagittis eros, ut tempor mi tincidunt tincidunt. Quisque quis nisi urna. Fusce convallis, magna non condimentum lacinia, erat dolor ullamcorper eros, a imperdiet metus neque vitae mauris. Ut auctor commodo consectetur. Suspendisse potenti. Ut id lorem in odio molestie pulvinar.\r\n\r\n                        </p>\r\n\r\n\r\n\r\n                        <p>\r\n\r\n                        Phasellus libero velit, dignissim nec posuere a, placerat quis lorem. Quisque quam turpis, sollicitudin vitae laoreet id, vulputate et justo. Maecenas ut mi tellus. Sed viverra sagittis molestie. Cras purus nisl, consectetur a tincidunt sit amet, semper sit amet ligula. Praesent feugiat facilisis felis eu blandit. Nullam vulputate, felis ut luctus lobortis, dui tellus consectetur dolor, sed porta nisi ligula a lorem. Mauris nec aliquam sapien. Integer consequat ante et erat tincidunt lobortis ut sit amet libero. Suspendisse vestibulum placerat justo, eu posuere leo suscipit a. Sed tristique tincidunt tempor. Aliquam id posuere enim. Donec pharetra est non leo pellentesque facilisis non a erat. Aenean tempus rhoncus nunc sed consequat. In luctus consequat leo, sed vestibulum dolor varius vitae. Ut faucibus porttitor aliquet. Phasellus ante felis, pulvinar id mattis rhoncus, faucibus vel mauris.\r\n\r\n                        </p>\r\n\r\n                        <p>\r\n\r\n                        Nam sapien massa, placerat a rhoncus eu, tempus at nunc. Suspendisse accumsan adipiscing blandit. Fusce in neque dolor, quis ultrices dolor. Sed blandit, nibh vel convallis porta, neque urna ornare augue, a tempor erat tellus quis quam. Nulla ullamcorper tristique sem, a fringilla diam dapibus sit amet. Suspendisse placerat aliquet turpis, at varius turpis accumsan eget. Mauris commodo malesuada ante. Donec vel sem neque. Nam tincidunt velit a tortor tempus in vestibulum justo molestie. Nullam eget augue urna, sed tempor massa. Praesent nec neque quam, id placerat enim. Integer nec orci nunc, eu tristique lorem. In nec libero ipsum, id venenatis orci. Morbi suscipit risus non justo vestibulum scelerisque vel nec orci. In ipsum ligula, porttitor nec scelerisque vel, auctor ut lectus. Ut convallis, sapien eget porttitor iaculis, nulla nisl rhoncus justo, id dignissim dolor nibh et metus. Proin cursus lacus id lorem convallis eu aliquam dolor malesuada.\r\n\r\n                        </p>\r\n\r\n                        <p>\r\n\r\n                        Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Quisque convallis fermentum gravida. Duis sagittis, velit non dictum condimentum, enim ante ullamcorper velit, sit amet rutrum magna ligula quis metus. Vivamus ut blandit enim. Donec hendrerit ante vitae nibh cursus in euismod nibh posuere. Vestibulum dictum pharetra diam, ac feugiat sem mollis posuere. Ut blandit tristique dui ac molestie. Mauris semper augue id velit condimentum sed egestas orci ornare. Proin purus ipsum, hendrerit sit amet posuere vitae, blandit et nibh. Suspendisse eget sollicitudin ligula. Morbi id bibendum est. Curabitur convallis, sem sit amet adipiscing ornare, mauris risus imperdiet quam, quis porta erat massa sed ipsum.\r\n\r\n                        </p>\r\n', 0, 0, 'dicas.html', 3, 'Dicas');

-- --------------------------------------------------------

--
-- Estrutura da tabela `endereco`
--

CREATE TABLE IF NOT EXISTS `endereco` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bairro` varchar(255) DEFAULT NULL,
  `cep` varchar(255) DEFAULT NULL,
  `municipio` varchar(255) DEFAULT NULL,
  `nomeDoLogrado` varchar(255) DEFAULT NULL,
  `numero` int(11) NOT NULL,
  `tipoDeLogradouro` varchar(255) DEFAULT NULL,
  `uf` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `endereco`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE IF NOT EXISTS `funcionario` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cpf` varchar(255) DEFAULT NULL,
  `dataDeNascimento` datetime DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `rg` varchar(255) DEFAULT NULL,
  `sexo` varchar(255) DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL,
  `matricula` varchar(255) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  `endereco_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`,`matricula`),
  KEY `FKB3A9C5BBEE21E5B1` (`endereco_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `funcionario`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `telefone`
--

CREATE TABLE IF NOT EXISTS `telefone` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ddd` varchar(255) DEFAULT NULL,
  `numero` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `telefone`
--


--
-- Restrições para as tabelas dumpadas
--

--
-- Restrições para a tabela `funcionario`
--
ALTER TABLE `funcionario`
  ADD CONSTRAINT `FKB3A9C5BBEE21E5B1` FOREIGN KEY (`endereco_id`) REFERENCES `endereco` (`id`);
